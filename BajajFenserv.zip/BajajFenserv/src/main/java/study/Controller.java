package study;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import study.Pojo;

@RestController
public class Controller {
	
	@PostMapping(path = "/bfhl")
	public Pojo insertcd(@PathVariable String[] numberarr) {
		Pojo e = new Pojo();
		e.setIs_success(true);
		e.setUser_id("nisha_makone_27111997");
		e.setEmail("makonenisha@gmail.com");
		e.setRoll_number("1234534568");
		
		String []arrnum = new String[numberarr.length];
		String []arralpha = new String[numberarr.length];
		int x=0,z=0;
		for(int i=0; i<numberarr.length; i++) {
			String checknum = numberarr[i];
			if(Character.isDigit(checknum.charAt(i))){
				arrnum[x] = numberarr[i];
				x++;
			}
			else {
				arralpha[z] = numberarr[i];
				z++;
			}
		}
		e.setNumbers(arrnum);
		e.setAlphabets(arralpha);
		return e;
	}
}


